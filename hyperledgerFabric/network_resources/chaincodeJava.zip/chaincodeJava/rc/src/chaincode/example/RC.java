package chaincode.example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.handler.codec.http.QueryStringDecoder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hyperledger.fabric.shim.ChaincodeBase;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.KeyValue;

public class RC extends ChaincodeBase {

    private static Log _logger = LogFactory.getLog(RC.class);
    private static ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Response init(ChaincodeStub stub) {
        try {
            _logger.info("Init");
            return newSuccessResponse();
        } catch (Throwable e) {
            return newErrorResponse(e);
        }
    }

    @Override
    public Response invoke(ChaincodeStub stub) {
        try {
            _logger.info("Invoke java simple chaincode");

            String func = stub.getFunction();
            List<String> params = stub.getParameters();

            switch (func) {
                case "methodRegister":
                    return methodRegister(stub, params);
                case "methodUpdate":
                    return methodUpdate(stub, params);
                case "methodDelete":
                    return methodDelete(stub, params);
                case "getContract":
                    return getContract(stub, params);
                case "getMethodNameList":
                    return getMethodNameList(stub, params);
                default:
                    return newErrorResponse("Invalid invoke function name");
            }
        } catch (Throwable e) {
            return newErrorResponse(e);
        }
    }

    private Response methodRegister(ChaincodeStub stub, List<String> args) {
        if (args.size() != 4) {
            return newErrorResponse("Incorrect number of arguments. Expecting 3");
        }

        try {
            final String methodName = args.get(0);
            final Identity subject = objectMapper.readValue(args.get(1), Identity.class);
            final String scName = args.get(2);
            final String abi = args.get(3);

            LookUpTable lookUpTable = LookUpTable.builder()
                    .methodName(methodName)
                    .subject(subject)
                    .objects(null)
                    .scName(scName)
                    .abi(abi)
                    .build();

            String lookUpTableBytes = objectMapper.writeValueAsString(lookUpTable);

            stub.putStringState(methodName, lookUpTableBytes);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return newErrorResponse("invoke finished successfully");
        }
        return newSuccessResponse("invoke finished successfully");
    }

    private Response methodUpdate(ChaincodeStub stub, List<String> args) {
        if (args.size() != 5) {
            return newErrorResponse("Incorrect number of arguments. Expecting 3");
        }

        try {
            final String methodName = args.get(0);
            final Identity subject = objectMapper.readValue(args.get(1), Identity.class);
            final ArrayList<Identity> objects = objectMapper.readValue(args.get(2), ArrayList.class);
            final String scName = args.get(3);
            final String abi = args.get(4);

            LookUpTable lookUpTable = LookUpTable.builder()
                    .methodName(methodName)
                    .subject(subject)
                    .objects(objects)
                    .scName(scName)
                    .abi(abi)
                    .build();

            String lookUpTableBytes = objectMapper.writeValueAsString(lookUpTable);

            stub.putStringState(methodName, lookUpTableBytes);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return newErrorResponse("invoke finished successfully");
        }
        return newSuccessResponse("invoke finished successfully");
    }

    // query callback representing the query of a chaincode
    private Response methodDelete(ChaincodeStub stub, List<String> args) {
        if (args.size() != 1) {
            return newErrorResponse("Incorrect number of arguments. Expecting name of the person to query");
        }

        try {
            String methodName = args.get(0);
            stub.delState(methodName);
        } catch (Exception e) {
            return newErrorResponse();
        }
        return newSuccessResponse();
    }

    private Response getContract(ChaincodeStub stub, List<String> args) {
        if (args.size() != 1) {
            return newErrorResponse("Incorrect number of arguments. Expecting name of the person to query");
        }

        final String methodName = args.get(0);
        byte[] lookUpTableBytes = stub.getState(methodName);

        return newSuccessResponse(new String(lookUpTableBytes));
    }

    private Response getMethodNameList(ChaincodeStub stub, List<String> args) {
        if (args.size() != 0) {
            return newErrorResponse("Incorrect number of arguments. Expecting name of the person to query");
        }

        try {
            final String queryString = "{\n" +
                    "   \"selector\": {\n" +
                    "      \"_id\": {\n" +
                    "         \"$regex\": \"\"\n" +
                    "      }\n" +
                    "   },\n" +
                    "   \"fields\": [\n" +
                    "      \"methodName\"\n" +
                    "   ]\n" +
                    "}";

            final Iterator<KeyValue> queryResultsIterator = stub.getQueryResult(queryString).iterator();

            ArrayList<String> methodNameList = new ArrayList<>();

            while (queryResultsIterator.hasNext()) {
                String queryResult = queryResultsIterator.next().getStringValue();
                methodNameList.add(queryResult);
            }

            String methodNameListJson = objectMapper.writeValueAsString(methodNameList);

            return newSuccessResponse(methodNameListJson);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return newErrorResponse();
        }
    }

    public static void main(String[] args) {
        new RC().start(args);
    }
}
